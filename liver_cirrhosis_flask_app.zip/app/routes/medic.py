# =============================================================
# app/routes/medic.py — Medic dashboard
# =============================================================
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from functools import wraps
from app.models import Patient, Prediction

medic = Blueprint('medic', __name__)


def medic_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role not in ['medic', 'admin']:
            flash('Medic access required.', 'danger')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated


@medic.route('/dashboard')
@login_required
@medic_required
def dashboard():
    # Summary stats
    total       = Patient.query.count()
    reviews     = Prediction.query.filter_by(confidence_flag='REVIEW').count()
    alive       = Prediction.query.filter_by(predicted_status='C').count()
    deceased    = Prediction.query.filter_by(predicted_status='D').count()
    transplant  = Prediction.query.filter_by(predicted_status='CL').count()

    # Recent flagged cases first, then the rest
    flagged = (Patient.query.join(Prediction)
               .filter(Prediction.confidence_flag == 'REVIEW')
               .order_by(Patient.submitted_at.desc())
               .limit(5).all())

    recent = (Patient.query.join(Prediction)
              .order_by(Patient.submitted_at.desc())
              .limit(8).all())

    return render_template('medic/dashboard.html',
        total=total, reviews=reviews,
        alive=alive, deceased=deceased, transplant=transplant,
        flagged=flagged, recent=recent
    )


@medic.route('/patients')
@login_required
@medic_required
def patients():
    # Filter by confidence flag if requested
    flag = request.args.get('flag', '')
    query = Patient.query.join(Prediction)

    if flag == 'REVIEW':
        query = query.filter(Prediction.confidence_flag == 'REVIEW')
    elif flag in ['C', 'CL', 'D']:
        query = query.filter(Prediction.predicted_status == flag)

    all_patients = query.order_by(Patient.submitted_at.desc()).all()
    return render_template('medic/patients.html',
                           patients=all_patients, active_flag=flag)


@medic.route('/patient/<int:patient_id>')
@login_required
@medic_required
def patient_detail(patient_id):
    patient    = Patient.query.get_or_404(patient_id)
    prediction = Prediction.query.filter_by(patient_id=patient_id).first_or_404()

    # Stage labels for display
    stage_labels = {
        1: ('Early', 'success'),
        2: ('Moderate', 'warning'),
        3: ('Advanced', 'orange'),
        4: ('End-stage', 'danger')
    }
    stage_label, stage_color = stage_labels.get(patient.stage, ('Unknown', 'secondary'))

    # Status badge colors
    status_colors = {'C': 'success', 'CL': 'warning', 'D': 'danger'}
    status_color  = status_colors.get(prediction.predicted_status, 'secondary')

    return render_template('medic/patient_detail.html',
        patient=patient,
        prediction=prediction,
        stage_label=stage_label,
        stage_color=stage_color,
        status_color=status_color
    )
